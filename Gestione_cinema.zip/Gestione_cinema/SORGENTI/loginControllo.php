<?php

   session_start();

   if(!isset($_GET["uname"]) || !isset($_GET["psw"]))
      header("Location: ../index.php");

   $dbHost = "localhost";
   $dbName = "dbcinema";
   $dbUser = $_GET["uname"];
   $dbPassw = $_GET["psw"];

   $connessione = mysqli_connect($dbHost, "root");
   if(!$connessione)
      die("Connessione fallita: ".mysql_error());

   mysqli_select_db($connessione, $dbName)
      or die("Impossibile selezionare il database ".$dbName);

   $result = mysqli_query($connessione, "SELECT * FROM loginutenti WHERE username='$dbUser' && passw='$dbPassw'");
   $result = mysqli_fetch_array($result);

   if($result!=null){
      $_SESSION["login_user"] = $dbUser;
      header("Location: ../index.php");
   }else{
      $_SESSION["login_user"] = "errore";
      echo "<p>L'utente non esiste</p>";
      echo "<a href=\"../index.php\">Torna alla home</a>";
   }
   
   mysqli_close($connessione);

?>