function controlloLogin(){
    msg = "";
    valido = false;
    
    if(form.uname.value == "" || form.psw.value == ""){
        msg = "Compilare tutti i campi!"
    }
    else{
        if(form.psw.value.length <= 5){
            msg = "Password troppo corta!";
        }
        else{
            if(!(form.psw.value.includes("@"))){
                msg = "La password deve contenere il carattere: @";
            }
            else{
                valido = true;
            }
        }
    }
    
    document.getElementById("display").innerText = msg;
    return valido;
}

/*function controlloAddUser(){
    msg = "";
    valido = false;
    
    if(formAdd.uname.value == "" || formAdd.psw.value == ""){
        msg = "Compilare tutti i campi!"
    }
    else{
        if(formAdd.psw.value.length <= 5){
            msg = "Password troppo corta!";
        }
        else{
            if(!(formAdd.psw.value.includes("@"))){
                msg = "La password deve contenere il carattere: @";
            }
            else{
                valido = true;
            }
        }
    }
    
    document.getElementById("displayAdd").innerText = msg;
    return valido;
}*/