<html>
    <head>
        <title>Gestione cinema - Programmazione</title>
        <link rel="stylesheet" href="../CSS/styleLogin.css"> 
        <script type="text/javascript" src="../SCRIPT/script.js"></script>
        <link href="../assets/img/cinepresa_favicon1.jpg" rel="icon">
    </head>

    <body>
        <?php
            session_start();

            if(!isset($_SESSION["login_user"]) || $_SESSION["login_user"] == "errore"){
                header("Location: ../index.php");
            }

            //Aggiunta
            if(isset($_GET["idCinema"]) && isset($_GET["settimana"]) && isset($_GET["idFilm"])){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $idCinema = $_GET["idCinema"];
                $settimana = $_GET["settimana"];
                $idFilm = $_GET["idFilm"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "INSERT INTO programmazione (fkCinema,settimana,fkFilm) VALUES ('$idCinema','$settimana','$idFilm')");

                if($ris){
                    echo "<script type='text/javascript'>alert('Programmazione aggiunta al database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Aggiunta non riuscita');</script>";
                }

                mysqli_close($connessione);
            } 

            //Rimozione
            if(isset($_GET["idCinemaRimuovi"]) && $_GET["idCinemaRimuovi"]!=0 && isset($_GET["idFilmRimuovi"]) && $_GET["idFilmRimuovi"]!=0 && isset($_GET["settimanaRimuovi"]) && $_GET["settimanaRimuovi"]!=0){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $cinema = $_GET["idCinemaRimuovi"];
                $settimana = $_GET["settimanaRimuovi"];
                $film = $_GET["idFilmRimuovi"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "DELETE FROM programmazione WHERE (fkCinema='$cinema' AND settimana='$settimana' AND fkFilm='$film')");

                if($ris){
                    echo "<script type='text/javascript'>alert('Programmazione rimossa dal database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Rimozione non riuscita');</script>";
                }

                mysqli_close($connessione);
            }
        ?>

        <!-- Aggiunta -->
        <form action="" method="GET" name="formProgrammazione">
    
            <div class="container">
        
            <label for="uname"><b>Cinema</b></label><br><br>
            <select name="idCinema" required>
            <?php
            session_start();
            $dbHost = "localhost";
            $dbName = "dbcinema";
            
               $connessione = mysqli_connect($dbHost, "root");
                    if(!$connessione)
                        die("Connessione fallita: ".mysql_error());
                           
                    mysqli_select_db($connessione, $dbName)
                        or die("Impossibile selezionare il database ".$dbName);  

                $res=mysqli_query($connessione, "SELECT * FROM `cinema`");
                while ( $row=mysqli_fetch_array($res)){
                    echo '<option value ="'.$row['idCinema'].'">'.$row['nome'].'</option>';

                }       
            ?>
            </select>
            <br><br>

            <label for="uname"><b>Settimana</b></label>
            <input type="text" placeholder="2" name="settimana" required>
            <br>

            <label for="uname"><b>Film</b></label><br><br>
            <select name="idFilm" required>
            <?php
            session_start();
            $dbHost = "localhost";
            $dbName = "dbcinema";
            
               $connessione = mysqli_connect($dbHost, "root");
                    if(!$connessione)
                        die("Connessione fallita: ".mysql_error());
                           
                    mysqli_select_db($connessione, $dbName)
                        or die("Impossibile selezionare il database ".$dbName);  

                $res=mysqli_query($connessione, "SELECT * FROM `film`");
                while ( $row=mysqli_fetch_array($res)){
                    echo '<option value ="'.$row['idFilm'].'">'.$row['titolo'].'</option>';

                }       
            ?>
            </select>
            
            <h5  id="display"></h5>   
        
            <button type="submit">AGGIUNGI</button>
            <br>
            <button onclick="window.location.href='../index.php'">Torna alla home</button>
            </div>  

        </form><br>

        <!-- Tuple -->
        <table style="width:60%">
            <tr>
                <th>Cinema</th>
                <th>Settimana</th>
                <th>Film</th>
            </tr>

            <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM programmazione");
                while($row= mysqli_fetch_array($ris)){
                    echo "<tr>";
                    //cinema
                    $idFk = $row["fkCinema"];
                    $fk = mysqli_fetch_array(mysqli_query($connessione, "SELECT * FROM cinema WHERE idCinema='$idFk'"));
                    echo "<td>".$fk["nome"]."</td>";
                    //settimana
                    echo "<td>".$row["settimana"]."</td>";
                    //film
                    $idFk = $row["fkFilm"];
                    $fk = mysqli_fetch_array(mysqli_query($connessione, "SELECT * FROM film WHERE idFilm='$idFk'"));
                    echo "<td>".$fk["titolo"]."</td>";
                    echo "</tr>";
                }
            ?>
        </table>

        <br><br>

        <!-- Rimozione -->
        <form classs="f2" action="" method="GET" name="formProgrammazioneRimuovi">
    
            <div class="container">
        
            <label for="uname"><b>Cinema</b></label>
            <br><br>
            <select name="idCinemaRimuovi" required>
                <option value ="0">--Seleziona Cinema--</option>
                <?php
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                        if(!$connessione)
                            die("Connessione fallita: ".mysql_error());
                                
                        mysqli_select_db($connessione, $dbName)
                            or die("Impossibile selezionare il database ".$dbName);  

                    $res=mysqli_query($connessione, "SELECT * FROM programmazione");
                    while ($row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['fkCinema'].'">';
                        $idFk = $row["fkCinema"];
                        $nome = mysqli_fetch_array(mysqli_query($connessione, "SELECT * FROM cinema WHERE idCinema='$idFk'"));
                        echo "".$nome['nome'].'</option>';

                    }       
                ?>
            </select><br><br>

            <label for="uname"><b>Settimana</b></label>
            <br><br>
            <select name="settimanaRimuovi" required>
                <option value ="0">--Seleziona Settimana--</option>
                <?php
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                        if(!$connessione)
                            die("Connessione fallita: ".mysql_error());
                                
                        mysqli_select_db($connessione, $dbName)
                            or die("Impossibile selezionare il database ".$dbName);  

                    $res=mysqli_query($connessione, "SELECT * FROM programmazione");
                    while ($row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['settimana'].'">'.$row['settimana'].'</option>';

                    }       
                ?>
            </select>

            <br><br>
            <label for="uname"><b>Film</b></label>
            <br><br>
            <select name="idFilmRimuovi" required>
                <option value ="0">--Seleziona Film--</option>
                <?php
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                        if(!$connessione)
                            die("Connessione fallita: ".mysql_error());
                                
                        mysqli_select_db($connessione, $dbName)
                            or die("Impossibile selezionare il database ".$dbName);  

                    $res=mysqli_query($connessione, "SELECT * FROM programmazione");
                    while ($row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['fkFilm'].'">';
                        $idFk = $row["fkFilm"];
                        $nome = mysqli_fetch_array(mysqli_query($connessione, "SELECT * FROM film WHERE idFilm='$idFk'"));
                        echo "".$nome['titolo'].'</option>';

                    }       
                ?>
            </select>
            
            <h5  id="display"></h5>   
        
            <button type="submit">RIMUOVI</button>
            </div>  

        </form>

    </body>
</html>