<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Gestione cinema</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/cinepresa_favicon1.jpg" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
 

</head>

<body>

    <?php
        session_start();
            if(isset($_SESSION["login_user"]) && $_SESSION["login_user"] != "errore"){
                include("SORGENTI/headerLogout.html");
            }else{
                include("SORGENTI/headerLogin.html");
            }
    ?> 
        

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container text-center position-relative" data-aos="fade-in" data-aos-delay="200">
      <h1>Gestione cinema</h1>
      <h2>Gestione di un database relativo all'organizzazione di cinema</h2>
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row content">
          <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">
            <h2>LA GESTIONE DEI CINEMA</h2>
            <h3>Questo sito ha lo scopo di simulare la gestione di diversi cinema, includendo anche l'inserimento e la rimozione di elementi</h3>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left" data-aos-delay="200">
            <p>
              Questo sito deve garantire alcune semplici funzioni necessarie per questo tipo di gestione:
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i>Possibilità di aggiungere elementi</li>
              <li><i class="ri-check-double-line"></i>Possibilità di rimuovere elementi</li>
              <li><i class="ri-check-double-line"></i>Possibilità di visualizzare elementi</li>
            </ul>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row counters">

          <div class="col-lg-3 col-6 text-center">
            <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM film");
                $film=0;
                while($row= mysqli_fetch_array($ris)){
                    $film++;
                }
                echo "<span data-purecounter-start='0' data-purecounter-end='$film' data-purecounter-duration='1' class='purecounter'></span>"
              ?>
              <p>Film</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
              <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM cinema");
                $cinema=0;
                while($row= mysqli_fetch_array($ris)){
                    $cinema++;
                }
                echo "<span data-purecounter-start='0' data-purecounter-end='$cinema' data-purecounter-duration='1' class='purecounter'></span>"
              ?>
              <p>Cinema</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
              <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM programmazione");
                $prog=0;
                while($row= mysqli_fetch_array($ris)){
                    $prog++;
                }
                echo "<span data-purecounter-start='0' data-purecounter-end='$prog' data-purecounter-duration='1' class='purecounter'></span>"
              ?>
              <p>Programmazioni</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
              <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM regista");
                $regista=0;
                while($row= mysqli_fetch_array($ris)){
                    $regista++;
                }
                echo "<span data-purecounter-start='0' data-purecounter-end='$regista' data-purecounter-duration='1' class='purecounter'></span>"
              ?>
              <p>Registi</p>
          </div>

        </div>

      </div>  
    </section><!-- End Counts Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container">
      <div class="section-title" data-aos="fade-right">
              <h2 align="center">PROGRAMMAZIONE</h2>
            </div>
        <table  class="table" style="width:60%" align="center">
            <tr>
                <th>Cinema</th>
                <th>Settimana</th>
                <th>Film</th>
            </tr>

            <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM programmazione");
                while($row= mysqli_fetch_array($ris)){
                    echo "<tr>";
                    //cinema
                    $idFk = $row["fkCinema"];
                    $fk = mysqli_fetch_array(mysqli_query($connessione, "SELECT * FROM cinema WHERE idCinema='$idFk'"));
                    echo "<td>".$fk["nome"]."</td>";
                    //settimana
                    echo "<td>".$row["settimana"]."</td>";
                    //film
                    $idFk = $row["fkFilm"];
                    $fk = mysqli_fetch_array(mysqli_query($connessione, "SELECT * FROM film WHERE idFilm='$idFk'"));
                    echo "<td>".$fk["titolo"]."</td>";
                    echo "</tr>";
                }
            ?>
        </table>
      </div>
    </section><!-- End Services Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team">
      <div class="container">

        <div class="row">
          <div class="col-lg-4">
            <div class="section-title" data-aos="fade-right">
              <h2>Team</h2>
              <p>Il team di lavoro:</p>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="row">

              <div class="col-lg-6">
                <div class="member" data-aos="zoom-in" data-aos-delay="100">
                  <div class="pic"><img src="assets/img/team/capoDeiCapi.jpg" class="img-fluid" alt=""></div>
                  <div class="member-info">
                    <h4>Matteo Pontalti</h4>
                    <span>Capo dei capi</span>
                    <p>Non ce n'è per nessuno</p>
                    <div class="social">
                      <a href=""><i class="ri-twitter-fill"></i></a>
                      <a href=""><i class="ri-facebook-fill"></i></a>
                      <a href=""><i class="ri-instagram-fill"></i></a>
                      <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-6 mt-4 mt-lg-0">
                <div class="member" data-aos="zoom-in" data-aos-delay="200">
                  <div class="pic"><img src="assets/img/team/fascista.jpg" class="img-fluid" alt=""></div>
                  <div class="member-info">
                    <h4>Cristiano Baldessari</h4>
                    <span>Disoccupato</span>
                    <p>Il king</p>
                    <div class="social">
                      <a href=""><i class="ri-twitter-fill"></i></a>
                      <a href=""><i class="ri-facebook-fill"></i></a>
                      <a href=""><i class="ri-instagram-fill"></i></a>
                      <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                    </div>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section><!-- End Team Section -->

  <!-- ======= Footer ======= -->
  <footer id="footer">      

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="credits">          
          Designed by <a href="https://bootstrapmade.com/">Matteo Pontalti & Cristiano Baldessari</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>