<html>
    <head>
        <title>Gestione cinema - Registi</title>
        <link rel="stylesheet" href="../CSS/styleLogin.css"> 
        <script type="text/javascript" src="../SCRIPT/script.js"></script>
        <link href="../assets/img/cinepresa_favicon1.jpg" rel="icon">
    </head>

    <body>
        <?php
            session_start();

            if(!isset($_SESSION["login_user"]) || $_SESSION["login_user"] == "errore"){
                header("Location: ../index.php");
            }

            //Aggiunta
            if(isset($_GET["nome"]) && isset($_GET["eta"])){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $nome = $_GET["nome"];
                $eta = $_GET["eta"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "INSERT INTO regista (nome,eta) VALUES ('$nome','$eta')");

                if($ris){
                    echo "<script type='text/javascript'>alert('Regista aggiunto al database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Aggiunta non riuscita');</script>";
                }

                mysqli_close($connessione);
            } 

            //Rimozione
            if(isset($_GET["idRegistaRimuovi"]) && $_GET["idRegistaRimuovi"]!=0){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $id = $_GET["idRegistaRimuovi"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "DELETE FROM regista WHERE idRegista='$id'");

                if($ris){
                    echo "<script type='text/javascript'>alert('Regista rimosso dal database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Rimozione non riuscita! Il regista è fk di un film');</script>";
                    //nel caso in cui un regista sia fk
                }

                mysqli_close($connessione);
            }
        ?>

        <!-- Aggiunta -->
        <form action="" method="GET" name="formRegista">
    
            <div class="container">
        
            <label for="uname"><b>Nome</b></label>
            <input type="text" placeholder="Mario" name="nome" required>
            <br>

            <label for="uname"><b>Eta</b></label>
            <input type="text" placeholder="69" name="eta" required>
            
            <h5  id="display"></h5>   
        
            <button type="submit">AGGIUNGI</button>
            <br>
            <button onclick="window.location.href='../index.php'">Torna alla home</button>
            </div>  

        </form><br>

        <!-- Tuple -->
        <table style="width:60%">
            <tr>
                <th>IdRegista</th>
                <th>Nome</th>
                <th>Età</th>
            </tr>

            <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM regista");
                while($row= mysqli_fetch_array($ris)){
                    echo "<tr>";
                    echo "<td>".$row["idRegista"]."</td><td>".$row["nome"]."</td><td>".$row["eta"]."</td>";
                    echo "</tr>";
                }
            ?>
        </table>

        <br><br>

        <!-- Rimozione -->
        <form classs="f2" action="" method="GET" name="formRegistaRimuovi">
    
            <div class="container">
        
            <label for="uname"><b>Nome Regista</b></label>
            <br><br>
            <select name="idRegistaRimuovi" required>
                <option value ="0">--Seleziona Regista--</option>
                <?php
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                        if(!$connessione)
                            die("Connessione fallita: ".mysql_error());
                                
                        mysqli_select_db($connessione, $dbName)
                            or die("Impossibile selezionare il database ".$dbName);  

                    $res=mysqli_query($connessione, "SELECT * FROM regista");
                    while ($row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['idRegista'].'">'.$row['nome'].'</option>';

                    }       
                ?>
            </select>
            
            <h5  id="display"></h5>   
        
            <button type="submit">RIMUOVI</button>
            </div>  

        </form>

    </body>
</html>