<html>
    <head>
        <title>Gestione cinema - Attori</title>
        <link rel="stylesheet" href="../CSS/styleLogin.css"> 
        <script type="text/javascript" src="../SCRIPT/script.js"></script>
        <link href="../assets/img/cinepresa_favicon1.jpg" rel="icon">
    </head>

    <body>
        <?php
            session_start();

            if(!isset($_SESSION["login_user"]) || $_SESSION["login_user"] == "errore"){
                header("Location: ../index.php");
            }

            //Aggiunta
            if(isset($_GET["nome"]) && isset($_GET["naz"])){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $nome = $_GET["nome"];
                $naz = $_GET["naz"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "INSERT INTO attore (nome,nazionalita) VALUES ('$nome','$naz')");

                if($ris){
                    echo "<script type='text/javascript'>alert('Attore aggiunto al database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Aggiunta non riuscita');</script>";
                }

                mysqli_close($connessione);
            }  

            //Rimozione
            if(isset($_GET["idAttoreRimuovi"]) && $_GET["idAttoreRimuovi"]!=0){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $id = $_GET["idAttoreRimuovi"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "DELETE FROM attore WHERE idAttore='$id'");

                if($ris){
                    echo "<script type='text/javascript'>alert('Attore rimosso dal database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Rimozione non riuscita! L\'attore è fk di un cast');</script>";
                    //nel caso in cui un attore sia fk in cast
                }

                mysqli_close($connessione);
            }

        ?>
        
        <!-- Aggiunta -->
        <form classs="f1" action="" method="GET" name="formAttore">
    
            <div class="container">
        
            <label for="uname"><b>Nome</b></label>
            <input type="text" placeholder="Mario" name="nome" required>
            <br>

            <label for="uname"><b>Nazionalità</b></label>
            <input type="text" placeholder="Italiana" name="naz" required>
            
            <h5  id="display"></h5>   
        
            <button type="submit">AGGIUNGI</button>
            <br>
            <button onclick="window.location.href='../index.php'">Torna alla home</button>
            </div>  

        </form>

        <br>

        <!-- Tuple -->
        <table style="width:60%">
            <tr>
                <th>IdAttore</th>
                <th>Nome</th>
                <th>Nazionalità</th>
            </tr>

            <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM attore");
                while($row= mysqli_fetch_array($ris)){
                    echo "<tr>";
                    echo "<td>".$row["idAttore"]."</td><td>".$row["nome"]."</td><td>".$row["nazionalita"]."</td>";
                    echo "</tr>";
                }
            ?>
        </table>

        <br><br>

        <!-- Rimozione -->
        <form classs="f2" action="" method="GET" name="formAttoreRimuovi">
    
            <div class="container">
        
            <label for="uname"><b>Nome Attore</b></label>
            <br><br>
            <select name="idAttoreRimuovi" required>
                <option value ="0">--Seleziona Attore--</option>
                <?php
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                        if(!$connessione)
                            die("Connessione fallita: ".mysql_error());
                                
                        mysqli_select_db($connessione, $dbName)
                            or die("Impossibile selezionare il database ".$dbName);  

                    $res=mysqli_query($connessione, "SELECT * FROM attore");
                    while ($row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['idAttore'].'">'.$row['nome'].'</option>';

                    }       
                ?>
            </select>
            
            <h5  id="display"></h5>   
        
            <button type="submit">RIMUOVI</button>
            </div>  

        </form>

    </body>
</html>