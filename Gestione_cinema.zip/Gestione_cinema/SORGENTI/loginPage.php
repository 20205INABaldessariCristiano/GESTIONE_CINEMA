<html>
    <head>
        <title>Gestione cinema - Login</title>
        <link rel="stylesheet" href="../CSS/styleLogin.css"> 
        <script type="text/javascript" src="../SCRIPT/script.js"></script>
        <link href="../assets/img/login.png" rel="icon">
    </head>

    <body>
        <form class="log" action="loginControllo.php" method="GET" name="form" onsubmit="return controlloLogin();">
    
            <div class="container">
            <label for="uname"><b>Username</b></label>
            <input type="text" placeholder="Username" name="uname" required>
            <br>
        
            <label for="psw"><b>Password</b></label>
            <input type="password" placeholder="*******" name="psw" required>
            
            <h5  id="display"></h5>   
        
            <button type="submit">Login</button>
            </div>
        
        </form>
    </body>
</html>