<html>
    <head>
        <title>Gestione cinema - Film</title>
        <link rel="stylesheet" href="../CSS/styleLogin.css"> 
        <script type="text/javascript" src="../SCRIPT/script.js"></script>
        <link href="../assets/img/cinepresa_favicon1.jpg" rel="icon">
    </head>

    <body>
        <?php
            session_start();
            
            if(!isset($_SESSION["login_user"]) || $_SESSION["login_user"] == "errore"){
                header("Location: ../index.php");
            }

            //Aggiunta
            if(isset($_GET["titolo"]) && isset($_GET["genere"]) && isset($_GET["regista"])){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $titolo = $_GET["titolo"];
                $genere = $_GET["genere"];
                $regista = $_GET["regista"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
        
                $ris = mysqli_query($connessione, "INSERT INTO film (titolo,genere,fkRegista) VALUES ('$titolo','$genere','$regista')");

                if($ris){
                    echo "<script type='text/javascript'>alert('Film aggiunto al database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Aggiunta non riuscita');</script>";
                }

                mysqli_close($connessione);
            } 

            //Rimozione
            if(isset($_GET["idFilmRimuovi"]) && $_GET["idFilmRimuovi"]!=0){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $id = $_GET["idFilmRimuovi"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                //Prima è necessario eliminare il cast, i premi e la programmazione relativi a tale film
                $ris = mysqli_query($connessione, "DELETE FROM castt WHERE fkFilm='$id'");
                $ris = mysqli_query($connessione, "DELETE FROM premi WHERE fkFilm='$id'");
                $ris = mysqli_query($connessione, "DELETE FROM programmazione WHERE fkFilm='$id'");
            
                $ris = mysqli_query($connessione, "DELETE FROM film WHERE idFilm='$id'");

                if($ris){
                    echo "<script type='text/javascript'>alert('Film e relativi premi e cast rimossi dal database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Rimozione non riuscita');</script>";
                }

                mysqli_close($connessione);
            }
        ?>

        <!-- Aggiunta -->
        <form action="" method="GET" name="formFilm">
    
            <div class="container">
        
            <label for="uname"><b>Titolo</b></label>
            <input type="text" placeholder="Il bambino col pigiama a righe" name="titolo" required>
            <br>

            <label for="uname"><b>Genere</b></label>
            <input type="text" placeholder="Fantasy" name="genere" required>
            <br>
             
            <label for="uname"><b>Regista</b></label><br><br>
            <select name="regista" required>
                <?php
                    session_start();
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                    if(!$connessione)
                        die("Connessione fallita: ".mysql_error());
                                
                    mysqli_select_db($connessione, $dbName)
                        or die("Impossibile selezionare il database ".$dbName);      
                    $res=mysqli_query($connessione, "SELECT * FROM `regista`");
                    while ( $row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['idRegista'].'">'.$row['nome'].'</option>';
                    }       
                ?>               
            </select>
        
            
            <h5  id="display"></h5>   
        
            <button type="submit">AGGIUNGI</button>
            <br>
            <button onclick="window.location.href='../index.php'">Torna alla home</button>
            </div>  

        </form><br>

        <!-- Tuple -->
        <table style="width:60%">
            <tr>
                <th>IdFilm</th>
                <th>Titolo</th>
                <th>Genere</th>
                <th>Regista</th>
            </tr>

            <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM film");
                while($row= mysqli_fetch_array($ris)){
                    echo "<tr>";
                    echo "<td>".$row["idFilm"]."</td><td>".$row["titolo"]."</td><td>".$row["genere"]."</td>";
                    $idRegistaFk = $row["fkRegista"];
                    $regista = mysqli_fetch_array(mysqli_query($connessione, "SELECT * FROM regista WHERE idRegista='$idRegistaFk'"));
                    echo "<td>".$regista["nome"]."</td>";
                    echo "</tr>";
                }
            ?>
        </table>

        <br><br>

        <!-- Rimozione -->
        <form classs="f2" action="" method="GET" name="formFilmRimuovi">
    
            <div class="container">
        
            <label for="uname"><b>ID Film</b></label>
            <br><br>
            <select name="idFilmRimuovi" required>
                <option value ="0">--Seleziona Film--</option>
                <?php
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                        if(!$connessione)
                            die("Connessione fallita: ".mysql_error());
                                
                        mysqli_select_db($connessione, $dbName)
                            or die("Impossibile selezionare il database ".$dbName);  

                    $res=mysqli_query($connessione, "SELECT * FROM film");
                    while ($row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['idFilm'].'">'.$row['idFilm'].'</option>';

                    }       
                ?>
            </select>
            
            <h5  id="display"></h5>   
        
            <button type="submit">RIMUOVI</button>
            </div>  

        </form>

    </body>
</html>