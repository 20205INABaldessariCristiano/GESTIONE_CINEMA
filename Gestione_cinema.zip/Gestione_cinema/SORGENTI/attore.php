<html>
    <head>
        <title>Attori</title>
        <link rel="stylesheet" href="../CSS/styleLogin.css"> 
        <script type="text/javascript" src="../SCRIPT/script.js"></script>
        <link href="../assets/img/cinepresa_favicon1.jpg" rel="icon">
    </head>

    <body>
        <?php
            session_start();

            if(isset($_GET["nome"]) && isset($_GET["naz"])){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $nome = $_GET["nome"];
                $naz = $_GET["naz"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "INSERT INTO attore (nome,nazionalita) VALUES ('$nome','$naz')");

                if($ris){
                    echo "<script type='text/javascript'>alert('Attore aggiunto al database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Aggiunta non riuscita');</script>";
                }

                mysqli_close($connessione);
            } 
        ?>

        <form action="" method="GET" name="formAttore">
    
            <div class="container">
        
            <label for="uname"><b>Nome</b></label>
            <input type="text" placeholder="Mario" name="nome" required>
            <br>

            <label for="uname"><b>Nazionalità</b></label>
            <input type="text" placeholder="Italiana" name="naz" required>
            
            <h5  id="display"></h5>   
        
            <button type="submit">AGGIUNGI</button>
            <br>
            <button onclick="window.location.href='../index.php'">Torna alla home</button>
            </div>  

        </form>
    </body>
</html>