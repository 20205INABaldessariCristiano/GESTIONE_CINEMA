-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 12, 2021 alle 23:49
-- Versione del server: 10.4.14-MariaDB
-- Versione PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbcinema`
--
CREATE DATABASE IF NOT EXISTS `dbcinema` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbcinema`;

-- --------------------------------------------------------

--
-- Struttura della tabella `attore`
--

CREATE TABLE `attore` (
  `idAttore` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `nazionalita` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `attore`
--

INSERT INTO `attore` (`idAttore`, `nome`, `nazionalita`) VALUES
(1, 'Cristiano ', 'Italiano');

-- --------------------------------------------------------

--
-- Struttura della tabella `cast`
--

CREATE TABLE `cast` (
  `fkAttore` int(11) NOT NULL,
  `fkFilm` int(11) NOT NULL,
  `personaggio` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `cast`
--

INSERT INTO `cast` (`fkAttore`, `fkFilm`, `personaggio`) VALUES
(1, 1, 'Berlusconi'),
(1, 2, 'Bambino Morto');

-- --------------------------------------------------------

--
-- Struttura della tabella `cinema`
--

CREATE TABLE `cinema` (
  `idCinema` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `citta` varchar(100) NOT NULL,
  `nPosti` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `cinema`
--

INSERT INTO `cinema` (`idCinema`, `nome`, `citta`, `nPosti`) VALUES
(1, 'ao', 'Sopramonte', 100);

-- --------------------------------------------------------

--
-- Struttura della tabella `film`
--

CREATE TABLE `film` (
  `idFilm` int(11) NOT NULL,
  `titolo` varchar(100) NOT NULL,
  `genere` varchar(100) NOT NULL,
  `fkRegista` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `film`
--

INSERT INTO `film` (`idFilm`, `titolo`, `genere`, `fkRegista`) VALUES
(1, 'Il bambino col pigiama a righe', 'Fantasy', 1),
(2, 'Shindler List', 'Fantasy', 2),
(7, 'La sboccata di simone', 'horror', 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `loginutenti`
--

CREATE TABLE `loginutenti` (
  `username` varchar(20) NOT NULL,
  `passw` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `loginutenti`
--

INSERT INTO `loginutenti` (`username`, `passw`) VALUES
('matteo', '111@111'),
('cristiano', '222@222');

-- --------------------------------------------------------

--
-- Struttura della tabella `premi`
--

CREATE TABLE `premi` (
  `idPremio` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `anno` int(11) NOT NULL,
  `fkFilm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `premi`
--

INSERT INTO `premi` (`idPremio`, `nome`, `anno`, `fkFilm`) VALUES
(1, 'SAAAS', 2005, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `programmazione`
--

CREATE TABLE `programmazione` (
  `fkCinema` int(11) NOT NULL,
  `settimana` int(11) NOT NULL,
  `fkFilm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `programmazione`
--

INSERT INTO `programmazione` (`fkCinema`, `settimana`, `fkFilm`) VALUES
(1, 2, 1),
(1, 3, 7);

-- --------------------------------------------------------

--
-- Struttura della tabella `regista`
--

CREATE TABLE `regista` (
  `idRegista` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `eta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `regista`
--

INSERT INTO `regista` (`idRegista`, `nome`, `eta`) VALUES
(1, 'SKUSKU', 69),
(2, 'Lino Banfi', 55),
(3, 'Barbara Marrocco', 19);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `attore`
--
ALTER TABLE `attore`
  ADD PRIMARY KEY (`idAttore`);

--
-- Indici per le tabelle `cast`
--
ALTER TABLE `cast`
  ADD KEY `fk_attore` (`fkAttore`),
  ADD KEY `fkFilm` (`fkFilm`);

--
-- Indici per le tabelle `cinema`
--
ALTER TABLE `cinema`
  ADD PRIMARY KEY (`idCinema`);

--
-- Indici per le tabelle `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`idFilm`),
  ADD KEY `fk_regista` (`fkRegista`);

--
-- Indici per le tabelle `premi`
--
ALTER TABLE `premi`
  ADD PRIMARY KEY (`idPremio`),
  ADD KEY `fkFilm` (`fkFilm`);

--
-- Indici per le tabelle `programmazione`
--
ALTER TABLE `programmazione`
  ADD KEY `fk_cinema` (`fkCinema`),
  ADD KEY `fk_film` (`fkFilm`);

--
-- Indici per le tabelle `regista`
--
ALTER TABLE `regista`
  ADD PRIMARY KEY (`idRegista`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `attore`
--
ALTER TABLE `attore`
  MODIFY `idAttore` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `cinema`
--
ALTER TABLE `cinema`
  MODIFY `idCinema` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `film`
--
ALTER TABLE `film`
  MODIFY `idFilm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `premi`
--
ALTER TABLE `premi`
  MODIFY `idPremio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `regista`
--
ALTER TABLE `regista`
  MODIFY `idRegista` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `cast`
--
ALTER TABLE `cast`
  ADD CONSTRAINT `cast_ibfk_1` FOREIGN KEY (`fkFilm`) REFERENCES `film` (`idFilm`),
  ADD CONSTRAINT `fk_attore` FOREIGN KEY (`fkAttore`) REFERENCES `attore` (`idAttore`);

--
-- Limiti per la tabella `film`
--
ALTER TABLE `film`
  ADD CONSTRAINT `fk_regista` FOREIGN KEY (`fkRegista`) REFERENCES `regista` (`idRegista`);

--
-- Limiti per la tabella `premi`
--
ALTER TABLE `premi`
  ADD CONSTRAINT `premi_ibfk_1` FOREIGN KEY (`fkFilm`) REFERENCES `film` (`idFilm`);

--
-- Limiti per la tabella `programmazione`
--
ALTER TABLE `programmazione`
  ADD CONSTRAINT `fk_cinema` FOREIGN KEY (`fkCinema`) REFERENCES `cinema` (`idCinema`),
  ADD CONSTRAINT `fk_film` FOREIGN KEY (`fkFilm`) REFERENCES `film` (`idFilm`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
