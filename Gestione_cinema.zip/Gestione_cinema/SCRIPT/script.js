function controlloLogin(){
    msg = "";
    valido = false;
    
    if(form.uname.value == "" || form.psw.value == ""){
        msg = "Compilare tutti i campi!"
    }
    else{
        if(form.psw.value.length <= 5){
            msg = "Password troppo corta!";
        }
        else{
            if(!(form.psw.value.includes("@"))){
                msg = "La password deve contenere il carattere: @";
            }
            else{
                valido = true;
            }
        }
    }
    
    document.getElementById("display").innerText = msg;
    return valido;
}
