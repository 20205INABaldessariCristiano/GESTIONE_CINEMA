<html>
    <head>
        <title>Gestione cinema - Cinema</title>
        <link rel="stylesheet" href="../CSS/styleLogin.css"> 
        <script type="text/javascript" src="../SCRIPT/script.js"></script>
        <link href="../assets/img/cinepresa_favicon1.jpg" rel="icon">
    </head>

    <body>
        <?php
            session_start();

            if(!isset($_SESSION["login_user"]) || $_SESSION["login_user"] == "errore"){
                header("Location: ../index.php");
            }

            //Aggiunta
            if(isset($_GET["nome"]) && isset($_GET["citta"]) && isset($_GET["nposti"])){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $nome = $_GET["nome"];
                $citta = $_GET["citta"];
                $nposti = $_GET["nposti"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "INSERT INTO cinema (nome,citta,nposti) VALUES ('$nome','$citta','$nposti')");

                if($ris){
                    echo "<script type='text/javascript'>alert('Cinema aggiunto al database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Aggiunta non riuscita');</script>";
                }

                mysqli_close($connessione);
            } 

            //Rimozione
            if(isset($_GET["idCinemaRimuovi"]) && $_GET["idCinemaRimuovi"]!=0){
                $dbHost = "localhost";
                $dbName = "dbcinema";
                $id = $_GET["idCinemaRimuovi"];

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);
            
                $ris = mysqli_query($connessione, "DELETE FROM cinema WHERE idCinema='$id'");

                if($ris){
                    echo "<script type='text/javascript'>alert('Cinema rimosso dal database');</script>";
                }else{
                    echo "<script type='text/javascript'>alert('Rimozione non riuscita');</script>";
                }

                mysqli_close($connessione);
            }
        ?>

        <!-- Aggiunta -->
        <form action="" method="GET" name="formCinema">
    
            <div class="container">
        
            <label for="uname"><b>Nome</b></label>
            <input type="text" placeholder="Example" name="nome" required>
            <br>

            <label for="uname"><b>Città</b></label>
            <input type="text" placeholder="Baselga del Bondone" name="citta" required>
            <br>

            <label for="uname"><b>Num Posti</b></label>
            <input type="text" placeholder="50" name="nposti" required>
            
            <h5  id="display"></h5>   
        
            <button type="submit">AGGIUNGI</button>
            <br>
            <button onclick="window.location.href='../index.php'">Torna alla home</button>
            </div>  

        </form><br>

        <!-- Tuple -->
        <table style="width:60%">
            <tr>
                <th>IdCinema</th>
                <th>Nome</th>
                <th>Città</th>
                <th>nPosti</th>
            </tr>

            <?php
                $dbHost = "localhost";
                $dbName = "dbcinema";

                $connessione = mysqli_connect($dbHost, "root");
                if(!$connessione)
                    die("Connessione fallita: ".mysql_error());
                    
                mysqli_select_db($connessione, $dbName)
                    or die("Impossibile selezionare il database ".$dbName);

                $ris = mysqli_query($connessione, "SELECT * FROM cinema");
                while($row= mysqli_fetch_array($ris)){
                    echo "<tr>";
                    echo "<td>".$row["idCinema"]."</td><td>".$row["nome"]."</td><td>".$row["citta"]."</td><td>".$row["nPosti"]."</td>";
                    echo "</tr>";
                }
            ?>
        </table>

        <br><br>

        <!-- Rimozione -->
        <form classs="f2" action="" method="GET" name="formCinemaRimuovi">
    
            <div class="container">
        
            <label for="uname"><b>Nome Cinema</b></label>
            <br><br>
            <select name="idCinemaRimuovi" required>
                <option value ="0">--Seleziona Cinema--</option>
                <?php
                    $dbHost = "localhost";
                    $dbName = "dbcinema";
                    
                    $connessione = mysqli_connect($dbHost, "root");
                        if(!$connessione)
                            die("Connessione fallita: ".mysql_error());
                                
                        mysqli_select_db($connessione, $dbName)
                            or die("Impossibile selezionare il database ".$dbName);  

                    $res=mysqli_query($connessione, "SELECT * FROM cinema");
                    while ($row=mysqli_fetch_array($res)){
                        echo '<option value ="'.$row['idCinema'].'">'.$row['nome'].'</option>';
                    }       
                ?>
            </select>
            
            <h5  id="display"></h5>   
        
            <button type="submit">RIMUOVI</button>
            </div>  

        </form>

    </body>
</html>